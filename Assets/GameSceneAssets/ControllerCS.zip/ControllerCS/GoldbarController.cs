using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GoldbarController : MonoBehaviour
{
    GameObject human;
    GameObject humanShoes;
    GameObject taxi;
    GameObject ferrari;
    GameObject point;
    string[] movingAssets = { "human_with_basket", "human_with_basket_with_shoes", "taxi", "ferrari" };
    GameObject gameDirector;
    public int goldbarPoint = 100;
    public float goldbarSpeed = 0.01f;
    public float goldbarRotationSpeed = 0.001f;
    float leftXCoordinate;
    float rightXCoordinate;
    float topYCoordinate;
    float bottomYCoordinate;
    private AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

        this.human = GameObject.Find(movingAssets[0]);
        this.humanShoes = GameObject.Find(movingAssets[1]);
        this.taxi = GameObject.Find(movingAssets[2]);
        this.ferrari = GameObject.Find(movingAssets[3]);
        gameDirector = GameObject.Find("GameDirector2");

        Camera mainCamera = Camera.main;

        // ī�޶��� �þ� ������ ���� ��ǥ�� ��ȯ
        Vector3 cameraMin = mainCamera.ViewportToWorldPoint(new Vector3(0, 0, mainCamera.nearClipPlane));
        Vector3 cameraMax = mainCamera.ViewportToWorldPoint(new Vector3(1, 1, mainCamera.nearClipPlane));


        // �����¿��� ��ǥ�� �����ϴ� ����
        leftXCoordinate = cameraMin.x;
        rightXCoordinate = cameraMax.x;
        topYCoordinate = cameraMax.y;
        bottomYCoordinate = cameraMin.y;
    }

    // Update is called once per frame
    void Update()
    {
        float px = UnityEngine.Random.Range(leftXCoordinate, rightXCoordinate);
        transform.position = new Vector3(px, topYCoordinate, 0);
        transform.Translate(0, -goldbarSpeed, 0, Space.World);
        transform.Rotate(Vector3.forward, goldbarRotationSpeed);

        if (transform.position.y < bottomYCoordinate)
        {
            Destroy(gameObject);
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (Array.Exists(movingAssets, name => name == collision.gameObject.name))
        {
            audioSource = GetComponent<AudioSource>();
            audioSource.Play();
            gameDirector.GetComponent<GameDirector2>().IncreasePoints(goldbarPoint);
            Destroy(gameObject);
        }
    }
}
